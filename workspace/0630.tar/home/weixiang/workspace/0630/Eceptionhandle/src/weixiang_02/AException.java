package weixiang_02;

public class AException extends Exception {
	public AException(String message) {
		// TODO Auto-generated constructor stub
		super(message);
	}

}
